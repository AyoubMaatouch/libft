/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aymaatou <aymaatou@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/18 18:02:04 by aymaatou          #+#    #+#             */
/*   Updated: 2019/10/28 01:08:51 by aymaatou         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"


#include "libft.h"

static int			nb(char *occ_ptr, char c)
{
	int i;
	int nb_occ;

	i = 0;
	nb_occ = 0;
	while (occ_ptr[i] != 0)
	{
		if (occ_ptr[i] != c && (occ_ptr[i - 1] == c || i == 0))
			nb_occ++;
		i++;
	}
	return (nb_occ);
}
/*
static void			*dp_print(char *g_ptr, char *occ_ptr, char c, int i)
{
	int n;

	n = 0;
	while (n < i)
	{
		while (occ_ptr[n] == c)
			n++;
		g_ptr[n] = occ_ptr[n];
		n++;
	}
	g_ptr[n] = 0;
	return (g_ptr);
}*/

static void			free_ptr(char **ptr, int j)
{
	while (j)
		free(&ptr[j--]);
	free(ptr);
}

static int			str_len(char *occ_ptr, char c)
{
	int i;

	i = 0;
	while (occ_ptr[i] != 0)
	{
		if (occ_ptr[i] == c && occ_ptr[i + 1] != c)
			break ;
		i++;
	}
	return (i);
}

char				**ft_split(char const *s, char c)
{
	char			**g_ptr;
	char			*occ_ptr;
	int				i;
	int				nb_occ;
	static int		j;

	while (*s == c)
		s++;
	occ_ptr = (char*)s;
	nb_occ = nb(occ_ptr, c);
	if (!(g_ptr = (char **)malloc(nb_occ * sizeof(char *) + 1)))
		return (NULL);
	while (j < nb_occ)
	{
		i = str_len(occ_ptr, c);
		if (!(g_ptr[j] = (char *)malloc(sizeof(char) * i + 1)))
		{
			free_ptr(g_ptr, j - 1);
			return (NULL);
		}
		g_ptr[j] = ft_substr(occ_ptr, 0, i);
		g_ptr[j][i+1] = 0;
		occ_ptr += i + 1;
		j++;
	}
	return (g_ptr);
}
